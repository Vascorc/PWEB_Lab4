const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

const appName = 'teste123';
const userName = 'Vasco, Laia, Basilio';

const notasRouter = require('./Controllers/notas');

// Middleware para aceitar JSON
app.use(express.json());

// Middleware
app.use((req, res, next) => {
  const dataHora = new Date().toLocaleString();
  console.log(`[${dataHora}] Tipo de pedido: ${req.method} - Rota: ${req.originalUrl}`);
  next(); // Passa o controle para o próximo middleware ou rota
});

mongoose.connect('mongodb://localhost:27017/node3', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Conectado ao MongoDB com sucesso!');
  })
  .catch((err) => {
    console.error('Erro ao conectar ao MongoDB:', err);
  });

// Associando o router para a rota "/notas"
app.use('/notas', notasRouter);

app.listen(port, () => {
  console.log(`${appName} está a funcionar! \nIniciado por: ${userName} \nAceda em http://localhost:${port}`);
});
