const express = require('express');
const router = express.Router();
const Nota = require('../Models/notas'); 

// GET todas as notas
router.get('/', async (req, res) => {
  try {
    const notas = await Nota.find(); 
    res.status(200).json(notas); 
  } catch (err) {
    res.status(500).json({ message: 'Erro ao obter notas', error: err }); 
  }
});

// GET nota por código
router.get('/nota/:cod', async (req, res) => {
  const { cod } = req.params;
  try {
    const nota = await Nota.findOne({ codDisciplina: cod }); 
    if (!nota) {
      return res.status(404).json({ message: 'Nota não encontrada.' });
    }
    res.status(200).json(nota);
  } catch (err) {
    res.status(500).json({ message: 'Erro ao obter a nota', error: err }); 
  }
});

// POST para adicionar uma nova nota
router.post('/nota', async (req, res) => {
  const { codDisciplina, nomeProfessor, nomeDisciplina, nota } = req.body;

  if (!codDisciplina || !nomeProfessor || !nomeDisciplina || !nota) {
    return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
  }

  try {
    const novaNota = new Nota({ codDisciplina, nomeProfessor, nomeDisciplina, nota });
    await novaNota.save();
    res.status(201).json({ message: 'Nota adicionada com sucesso!', novaNota });
  } catch (err) {
    res.status(500).json({ message: 'Erro ao adicionar a nota', error: err });
  }
});


router.put('/nota/:cod', async (req, res) => {
  const { cod } = req.params;
  const { nomeProfessor, nomeDisciplina, nota } = req.body;
  try {
    const updatedNota = await Nota.findOneAndUpdate(
      { codDisciplina: cod },
      { nomeProfessor, nomeDisciplina, nota },
      { new: true } // Retorna o documento atualizado
    );
    if (!updatedNota) {
      return res.status(404).json({ message: 'Nota não encontrada.' });
    }
    res.status(200).json({ message: 'Nota atualizada com sucesso!', updatedNota }); 
  } catch (err) {
    res.status(500).json({ message: 'Erro ao atualizar a nota', error: err }); 
  }
});

// DELETE nota por código
router.delete('/nota/:cod', async (req, res) => {
  const { cod } = req.params;
  try {
    const deletedNota = await Nota.findOneAndDelete({ codDisciplina: cod });
    if (!deletedNota) {
      return res.status(404).json({ message: 'Nota não encontrada.' }); 
    }
    res.status(200).json({ message: 'Nota removida com sucesso!', deletedNota }); 
  } catch (err) {
    res.status(500).json({ message: 'Erro ao remover a nota', error: err }); 
  }
});

module.exports = router;